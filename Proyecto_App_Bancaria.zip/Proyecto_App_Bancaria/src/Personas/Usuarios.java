package Personas;

import Buzon.BuzonMensajes;
import Comentarios.Comentario;
import Comprobantes.ComprobanteSimpeEntrada;
import Comprobantes.ComprobanteSimpeSalida;
import Cuentas.CuentaAhorro;
import Cuentas.CuentaCorriente;
import Cuentas.CuentaSimpe;
import java.util.ArrayList;

public class Usuarios extends Personas {

    private boolean estadoUsuario = true;
    private boolean estadoCuenta = true;
    private Comentario comentario;
    private CuentaCorriente cuentaCorriente = new CuentaCorriente(true);
    private CuentaAhorro cuentaAhorro = new CuentaAhorro(false);
    private CuentaSimpe cuentaSimpe = new CuentaSimpe(false);
    private ArrayList<ComprobanteSimpeSalida> comprobantesSimpeSalida = new ArrayList<>();
    private ArrayList<ComprobanteSimpeEntrada> comprobantesSimpeEntrada = new ArrayList<>();
    private BuzonMensajes buzonMensajes = new BuzonMensajes();

    public Usuarios(String usuario, String apellidos, String password, String cedula, String telefono, int claveNumerica, int rol, int sede,
            double saldoDeLaCuenta, double saldoCuentaSimpe, double saldoCuentaAhorro) {

        super(usuario, apellidos, password, cedula, telefono, claveNumerica, rol, sede);
        this.cuentaCorriente.setSaldo(saldoDeLaCuenta);
        this.cuentaAhorro.setSaldo(saldoCuentaAhorro);
        this.cuentaSimpe.setSaldo(saldoCuentaSimpe);
    }

    public Usuarios() {

    }

    public CuentaCorriente getCuentaCorriente() {
        return cuentaCorriente;
    }

    public void setCuentaCorriente(CuentaCorriente cuentaCorriente) {
        this.cuentaCorriente = cuentaCorriente;
    }

    public CuentaAhorro getCuentaAhorro() {
        return cuentaAhorro;
    }

    public void setCuentaAhorro(CuentaAhorro cuentaAhorro) {
        this.cuentaAhorro = cuentaAhorro;
    }

    public CuentaSimpe getCuentaSimpe() {
        return cuentaSimpe;
    }

    public void setCuentaSimpe(CuentaSimpe cuentaSimpe) {
        this.cuentaSimpe = cuentaSimpe;
    }

    public ArrayList<ComprobanteSimpeSalida> getComprobantesSimpeSalida() {
        return comprobantesSimpeSalida;
    }

    public void setComprobantesSimpeSalida(ArrayList<ComprobanteSimpeSalida> comprobantesSimpeSalida) {
        this.comprobantesSimpeSalida = comprobantesSimpeSalida;
    }

    public ArrayList<ComprobanteSimpeEntrada> getComprobantesSimpeEntrada() {
        return comprobantesSimpeEntrada;
    }

    public void setComprobantesSimpeEntrada(ArrayList<ComprobanteSimpeEntrada> comprobantesSimpeEntrada) {
        this.comprobantesSimpeEntrada = comprobantesSimpeEntrada;
    }

    public boolean getEstadoUsuario() {
        return estadoUsuario;
    }

    public void setEstadoUsuario(boolean estadoUsuario) {
        this.estadoUsuario = estadoUsuario;
    }

    public boolean getEstadoCuenta() {
        return estadoCuenta;
    }

    public void setEstadoCuenta(boolean estadoCuenta) {
        this.estadoCuenta = estadoCuenta;
    }

    public Comentario getComentario() {
        return comentario;
    }

    public void setComentario(Comentario comentario) {
        this.comentario = comentario;
    }

    public BuzonMensajes getBuzonMensajes() {
        return buzonMensajes;
    }

    public void setBuzonMensajes(BuzonMensajes buzonMensajes) {
        this.buzonMensajes = buzonMensajes;
    }

}
